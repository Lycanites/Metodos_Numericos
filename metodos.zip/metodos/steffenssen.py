class steffenssen:
    print("o")